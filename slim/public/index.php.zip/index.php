<?php
require '../vendor/autoload.php';
$app = new \Slim\Slim(array(
    'mode' => 'development',
    'debug' => true,
    'templates.path' => '../app/views/'
    ));
//routes here

$app->get('/hello/:id', function ($id) use ($app) {
	//echo "Hello $id!";
	$app->render('hello.php', array('id' => $id));
	$app->redirect('student.php');

});


$app->run();
