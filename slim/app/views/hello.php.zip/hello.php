<?php
echo "Hello  $id!!";

echo $_ENV['SLIM_MODE'] = 'development';